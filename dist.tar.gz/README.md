


# BONUS NETWORK

op_netbind

First I pop an argument from the stack and convert it to a string as the specification requires it to be in that format. I use a struct addrinfo to indicate the arguments for creating the socket. In order to listen on a given port and accept connections, we have to call the bind, listen and accept methods and pass the socket and the struct arguments as parameters. Each time a method is called and fails I push 0 on stack and stop the instruction execution with return. If no problems occur I push a random unsigned number on the stack. At the end the created socket is pushed into an array for storage.

op_netconncect

First I pop two arguments from the stack. I take the ip and transform it using an algorithm found online. This time I use the sockaddr_in struct which is used for ip communication. This time I bind the socket, and connect to the given ip address on a given port. On failure 0 is pushed on the stack, otherwise an unsigned random number. At the end the created socket is pushed into an array for storage.

op_netin

First I pop the element of a stack, which contains netref (index in the socket_array where a socket is contained). Then recv is used to read a character into a buffer.

op_netout

Two elements are popped off the stack. The first is a char of the character to be written to the socket. The second is netref. the char needs to be put into an array as that is what is required for the send system call. The send() system call sends the character to the socket.

op_netclose

Pop netref off the stack, retrieve socket from socket_array, close the socket.
